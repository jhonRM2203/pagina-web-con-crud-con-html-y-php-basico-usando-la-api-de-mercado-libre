<?php
include 'conectar.php';
$conexion = Conexion::obtenerConexion();

$id = $_GET['id'];

$datos_usuario = "SELECT * FROM guitarras WHERE id = $id";
$res_usuario = mysqli_query($conexion, $datos_usuario);

while ($fila = mysqli_fetch_array($res_usuario)) {

    $id = $fila['id'];
    $title = $fila['title'];
    $base_price = $fila['price'];
    $thumbnail = $fila['thumbnail'];

}

if (isset($_POST['editar'])) {

    $title_editado = $_POST['title'];
    $base_price_editado = $_POST['price'];
    $thumbnail_editado = $_POST['thumbnail'];

    $editar_datos = "UPDATE guitarras SET title='$title_editado', price='$base_price_editado',
    thumbnail='$thumbnail_editado' WHERE id = $id";
    $res_editado = mysqli_query($conexion, $editar_datos);

    if ($editar_datos) {

        header("Location: index.php");

    } else {

        echo "No se ha podido editar el usuario";

    }

}

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css"
      integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="estilos.css" />
    <title>Editar usuario</title>
  </head>
  <body>
    <div class="contenedor">
      <a href="index.php">Volver</a>

      <form method="post">
        <br />
        Nombre: <input type="text" name="title" value="<?php echo $title; ?>" />
        <br />
        precio:
        <input type="text" name="price" value="<?php echo $base_price; ?>" />
        <br />
        imagen:
        <input type="text" name="thumbnail" value="<?php echo $thumbnail; ?>" />
        <br />
        <button type="submit" class="btn btn-warning" name="editar">
          Editar
        </button>
      </form>
    </div>
  </body>
</html>
