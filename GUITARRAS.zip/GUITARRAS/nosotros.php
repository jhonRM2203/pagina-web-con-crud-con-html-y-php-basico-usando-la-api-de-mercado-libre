<?php
?>
<!DOCTYPE html>
<html lang="es">
  <head>
    <title>monster sonud</title>
  </head>
  <body>
    <header>
      <h1 style="font-family: Chiller">MONSTER SOUND</h1>

      <audio controls>
        <source src="cancion.mp3.mp3" type="audio/mpeg" />
      </audio>
      <style>
        body {
          /* Establece el fondo de toda la página */
          background-image: url("img/fondo.gif"); /* Reemplaza 'ruta/a/tu/imagen.jpg' con la ruta de tu imagen */
          background-size: cover; /* Ajusta la imagen para cubrir todo el fondo */
          background-repeat: no-repeat; /* Evita que la imagen se repita */
        }
      </style>
    </header>
    <li><a href="index.php">INICIO</a></li>
    <li><a href="nosotros.php">NOSOTROS</a></li>
    <li><a href="crud.php">CRUD</a></li>

    <h2 style="color: aliceblue">Nosotros</h2>
    <p></p>
    <p style="color: aliceblue">
      MONSTER SOUND es una tienda virtual, aquí te vas a encontrar con una
      variedad de guitarras para el uso que le quieras dar.
    </p>
    <br />
    <p style="color: aliceblue">
      Hemos tenido siempre como prioridad darles productos de la mejor calidad,
      a precios accesibles y acompañado por un servicio al cliente de primera.
    </p>
    <br />
    <p style="color: aliceblue">
      La creación de una comunidad de clientes leales ha ayudado a nuestra
      tienda MONSTER SOUND a crecer y convertirse en la empresa que somos ahora.
      No solo somos una tienda virtual, nuestra empresa y todo nuestro equipo
      nos preocupamos y apoyamos a todas las personas que quieren entrar en el
      mundo de la musica.
    </p>
  </body>
</html>
