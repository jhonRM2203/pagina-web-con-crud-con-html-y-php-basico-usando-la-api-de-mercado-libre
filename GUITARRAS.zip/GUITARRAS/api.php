<?php
require_once '../GUITARRAS/conectar.php';

$conn = Conexion::obtenerConexion();

// URL de la API de Mercado Libre
$url = "https://api.mercadolibre.com/sites/MLM/search?q=guitarraselectricas";

// Obtener datos de la API
$response = file_get_contents($url);

// Decodificar la respuesta JSON
$data = json_decode($response, true);
// Verificar si hay datos
if (!empty($data['results'])) {
    // Recorrer los datos y guardarlos en la base de datos
    foreach ($data['results'] as $item) {
      $id = isset($item['id']) ? $item['id'] : '';
      $title = isset($item['title']) ? $item['title'] : '';
      $base_price = isset($item['price']) ? $item['price'] : '';
      $thumbnail = isset($item['thumbnail']) ? $item['thumbnail'] : '';
  
      // Insertar datos en la base de datos
      $sql = "INSERT INTO guitarras (id, title, price, thumbnail)
      VALUES ('$id','$title','$base_price','$thumbnail')";
  
      if ($conn->query($sql) === TRUE) {
        echo "Datos insertados correctamente";
        header("Location: index.php");
      } else {
        echo "Error al insertar datos: " . $conn->error;
      }
    }
  } else {
    echo "No se encontraron datos en la API";
}

// Cerrar conexión
$conn->close();

?>