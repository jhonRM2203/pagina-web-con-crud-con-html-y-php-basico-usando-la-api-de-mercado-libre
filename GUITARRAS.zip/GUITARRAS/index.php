<?php
require 'conectar.php';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="styles.css">
    <script src="app.js" async></script>
    <title>monster sonud</title>
</head>
<body>
    <header> 
        <h1 style="font-family:Chiller ;">MONSTER SOUND</h1>
        
        <audio controls>
            <source src="cancion.mp3.mp3" type="audio/mpeg"> 
        </audio>
        <style>
            body {
                /* Establece el fondo de toda la página */
                background-image: url('img/fondo.gif'); /* Reemplaza 'ruta/a/tu/imagen.jpg' con la ruta de tu imagen */
                background-size: cover; /* Ajusta la imagen para cubrir todo el fondo */
                background-repeat: no-repeat; /* Evita que la imagen se repita */
            }
        </style>
    </header>
        <li><a href="index.php">Inicio</a></li>
        <li><a href="nosotros.php">NOSOTROS</a></li>
        <li><a href="crud.php">CRUD MONSTRUES</a></li>
        <li><a href="api.php">MOSTRAR DATOS</a></li>

<div class="product-container">
            <?php
            $conexion = Conexion::obtenerConexion();
            $sql = "SELECT * FROM guitarras";
            $resultado = $conexion->query($sql);
            if ($resultado->num_rows > 0) {
                while ($fila = $resultado->fetch_assoc()) {

                    echo '<article class="product-item">';
                    echo '</a>';
                    echo '<h4>' . $fila['id'] . '</h4>';
                    echo '<p>title: $' . $fila['title'] . '</p>';
                    echo '<p>base_price: $' . $fila['price'] . '</p>';
                    echo '<img src="'.$fila ['thumbnail'].'">';
                    echo "<form method='post' action='api.php'>";
                    
                    echo "</form>";
                    echo '</article>';
                }
            } else {
                echo 'No se encontraron productos.';
            }
            $conexion->close();
            ?>
        </div>


    <!--<section class="contenedor">
         
        <div class="contenedor-items">
            <div class="item">
                <span class="titulo-item" style="font-family:Chiller ;">A2.6FR LEMON NEON MATTE</span>
                <img src="img/guitarra1.png.png" alt="" class="img-item">
                <span class="precio-item">$3.456.000</span>
                <button class="boton-item">COMPRAR</button>
            </div>
            <div class="item">
                <span class="titulo-item" style="font-family:Chiller ;">X2.61FRCAR+ ROJO MANZANA CARAMELO</span>
                <img src="img/guitarra2.png.png" alt="" class="img-item">
                <span class="precio-item">$3.200.000</span>
                <button class="boton-item">COMPRAR</button>
            </div>
            <div class="item">
                <span class="titulo-item" style="font-family:Chiller ;">A1.7FRCAR SUSTAINIAC+ ROJO MANZANA CARAMELO METALIZADO BRILLANTE</span>
                <img src="img/guitarra3.png" alt="" class="img-item">
                <span class="precio-item">$2.200.000</span>
                <button class="boton-item">COMPRAR</button>
            </div>
            <div class="item">
                <span class="titulo-item" style="font-family:Chiller ;">V1.6 CANIBALISMO LH+</span>
                <img src="img/guitarra4.png" alt="" class="img-item">
                <span class="precio-item">$3.500.000</span>
                <button class="boton-item">COMPRAR</button>
            </div>
            <div class="item">
                <span class="titulo-item" style="font-family:Chiller ;">T2.7LN+ NEÓN LIMÓN</span>
                <img src="img/guitarra10.png" alt="" class="img-item">
                <span class="precio-item">$4.300.000</span>
                <button class="boton-item">COMPRAR</button>
            </div>
            <div class="item">
                <span class="titulo-item" style="font-family:Chiller ;">GC2.6TBP TRANS PURPLE BURST MATTE</span>
                <img src="img/guitarra6.png" alt="" class="img-item">
                <span class="precio-item">$2.999.000</span>
                <button class="boton-item">COMPRAR</button>
            </div>
            <div class="item">
                <span class="titulo-item" style="font-family:Chiller ;">GC2.6C NEGRO CARBÓN MATE</span>
                <img src="img/guitarra7.png" alt="" class="img-item">
                <span class="precio-item">$4.897.000</span>
                <button class="boton-item">COMPRAR</button>
            </div>
            <div class="item">
                <span class="titulo-item" style="font-family:Chiller ;">X1.7OLA BLACK ON BLACK WITH OLA LOGO</span>
                <img src="img/guitarra8.png" alt="" class="img-item">
                <span class="precio-item">$3.550.000</span>
                <button class="boton-item">COMPRAR</button>
            </div>
            <div class="item">
                <span class="titulo-item" style="font-family:Chiller ;">T1.6D MATE NATURAL ENVEJECIDO / DESGASTADO</span>
                <img src="img/guitarra9.png" alt="" class="img-item">
                <span class="precio-item">$4.495.000</span>
                <button class="boton-item">COMPRAR</button>
            </div>
        </div>
        Carrito de Compras 
        <div class="carrito" id="carrito">
            <div class="header-carrito">
                <h2 style="font-family:Chiller ;">TU CARRITO</h2>
            </div>

            <div class="carrito-items">
            </div>
            <div class="carrito-total">
                <div class="fila">
                    <strong>Tu Total</strong>
                    <span class="carrito-precio-total" style="color: #000000;">
                        $120.000,00
                    </span>
                </div>
                <button class="btn-pagar" style="color: #fff;">Pagar <i class="fa-solid fa-bag-shopping"></i> </button>
            </div>
        </div>
    </section>-->
</body>
</html>